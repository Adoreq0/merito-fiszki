
  # Quiz App for WSB Merito

  This is a code bundle for Quiz App for WSB Merito. The original project is available at https://www.figma.com/design/UNah0ht4wIVw2NjArPK785/Quiz-App-for-WSB-Merito.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  